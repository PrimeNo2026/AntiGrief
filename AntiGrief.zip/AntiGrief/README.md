# AntiGrief 1.1

Admin-Befehle (Permission `antigrief.admin`, Standard: OP):

- `/AntiGrief Zone <Radius> <Farbe> <Name> <Message>` – viereckige Zone um deine Position
- `/AntiGrief Give <Spieler> <Anzahl> <MaxRadius>` – Spieler darf <Anzahl>-mal eine Zone bis MaxRadius platzieren
- `/AntiGrief History [Zonenname|Spieler] [Seite]` – wer hat was in welcher Zone gemacht
- `/AntiGrief Rollback <Zonenname> Place` – zerstörte Blöcke wieder hinsetzen
- `/AntiGrief Rollback <Zonenname> Destroy` – seit dem letzten Safe platzierte Blöcke entfernen
- `/AntiGrief Safe <Zonenname>` – aktuellen Zustand der Zone als neuen Anfangszustand übernehmen
- `/AntiGrief List`, `/AntiGrief Remove <Zonenname>`

Spieler mit Zonen-Möglichkeit (per Give) dürfen `/AntiGrief Zone ...` und `/AntiGrief Credits` benutzen.

Farben: rot, blau, gruen, gelb, orange, lila, pink, tuerkis, weiss, grau, schwarz, braun oder Hex wie `#FF8800`.

Hinweise: Wasser, Lava und Feuer zählen nicht als platzierte Blöcke. Kisten-Inhalte und Schilder-Text werden beim Rollback nicht wiederhergestellt.

Build: Projekt auf GitHub hochladen, `.github/workflows/build.yml` baut die JAR und legt sie unter "Releases" ab.
