package de.antigrief;

/** Blockposition (die Welt ergibt sich aus der Zone). */
public record Pos(int x, int y, int z) {
}
