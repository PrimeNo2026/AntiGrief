package de.antigrief;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/** Protokoll aller Änderungen in Zonen (die letzten MAX Einträge werden behalten). */
public final class HistoryStore {

    public record Entry(long time, String zone, String actor, String oldMat, String newMat,
                        int x, int y, int z) {
    }

    private static final int MAX = 20000;

    private final JavaPlugin plugin;
    private final File file;
    private final ArrayDeque<Entry> entries = new ArrayDeque<>();
    private final List<String> pending = new ArrayList<>();

    public HistoryStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "history.log");
    }

    public void load() {
        if (!file.exists()) {
            return;
        }
        try {
            List<String> lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
            int start = Math.max(0, lines.size() - MAX);
            for (int i = start; i < lines.size(); i++) {
                String[] p = lines.get(i).split("\\|", -1);
                if (p.length < 8) {
                    continue;
                }
                try {
                    entries.addLast(new Entry(Long.parseLong(p[0]), p[1], p[2], p[3], p[4],
                            Integer.parseInt(p[5]), Integer.parseInt(p[6]), Integer.parseInt(p[7])));
                } catch (NumberFormatException ignored) {
                    // kaputte Zeile überspringen
                }
            }
            if (start > 0) {
                List<String> keep = new ArrayList<>(lines.subList(start, lines.size()));
                Files.write(file.toPath(), keep, StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            plugin.getLogger().severe("history.log konnte nicht gelesen werden: " + e.getMessage());
        }
    }

    public void add(Entry e) {
        entries.addLast(e);
        while (entries.size() > MAX) {
            entries.pollFirst();
        }
        pending.add(e.time() + "|" + e.zone() + "|" + e.actor().replace('|', '/') + "|" + e.oldMat()
                + "|" + e.newMat() + "|" + e.x() + "|" + e.y() + "|" + e.z());
    }

    public void flush() {
        if (pending.isEmpty()) {
            return;
        }
        List<String> lines = new ArrayList<>(pending);
        pending.clear();
        try {
            plugin.getDataFolder().mkdirs();
            Files.write(file.toPath(), lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            plugin.getLogger().severe("history.log konnte nicht geschrieben werden: " + e.getMessage());
        }
    }

    /** Neueste zuerst. Filter dürfen null sein. */
    public List<Entry> query(String zoneName, String actorPart) {
        List<Entry> out = new ArrayList<>();
        Iterator<Entry> it = entries.descendingIterator();
        while (it.hasNext()) {
            Entry e = it.next();
            if (zoneName != null && !e.zone().equalsIgnoreCase(zoneName)) {
                continue;
            }
            if (actorPart != null && !e.actor().toLowerCase(Locale.ROOT).contains(actorPart.toLowerCase(Locale.ROOT))) {
                continue;
            }
            out.add(e);
        }
        return out;
    }
}
