package de.antigrief;

import org.bukkit.Material;
import org.bukkit.block.data.BlockData;

import java.util.Locale;

public final class BlockUtil {

    private BlockUtil() {
    }

    /** Luft, Wasser, Lava und Feuer zählen als "leer" (werden nicht als platzierte Blöcke gewertet). */
    public static boolean emptyLike(Material m) {
        return m.isAir() || m == Material.WATER || m == Material.LAVA
                || m == Material.FIRE || m == Material.SOUL_FIRE;
    }

    public static boolean emptyLikeName(String materialName) {
        Material m = Material.getMaterial(materialName);
        return m == null || emptyLike(m);
    }

    /** Zwei Blöcke gelten als gleich, wenn Material gleich ist (oder beide "leer" sind). */
    public static boolean equivalent(BlockData a, BlockData b) {
        Material x = a.getMaterial();
        Material y = b.getMaterial();
        if (emptyLike(x) && emptyLike(y)) {
            return true;
        }
        return x == y;
    }

    /** STONE_BRICKS -> Stone Bricks */
    public static String pretty(String materialName) {
        String[] parts = materialName.toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.toString();
    }
}
