package de.antigrief;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

public final class AntiGriefPlugin extends JavaPlugin implements Listener, TabCompleter {

    private static final String PERMISSION = "antigrief.admin";
    private static final int MAX_RADIUS = 1000;
    private static final int MAX_CREDITS_PER_GIVE = 100;
    private static final int HISTORY_PAGE_SIZE = 8;
    private static final int ROLLBACK_BLOCKS_PER_TICK = 500;
    private static final double RENDER_DISTANCE = 40;
    private static final double LINE_RANGE = 24;
    private static final Pattern NAME_PATTERN = Pattern.compile("[A-Za-z0-9_-]{1,24}");
    private static final DateTimeFormatter TIME_FORMAT =
            DateTimeFormatter.ofPattern("dd.MM. HH:mm").withZone(ZoneId.systemDefault());

    private ZoneManager zones;
    private CreditManager credits;
    private HistoryStore history;
    private final Set<String> busy = new HashSet<>();

    @Override
    public void onEnable() {
        zones = new ZoneManager(this);
        zones.load();
        credits = new CreditManager(this);
        credits.load();
        history = new HistoryStore(this);
        history.load();

        var cmd = getCommand("antigrief");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getPluginManager().registerEvents(new ChangeTracker(this, zones, history), this);
        Bukkit.getScheduler().runTaskTimer(this, this::drawBorders, 20L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            zones.flushDirty(true);
            history.flush();
        }, 200L, 200L);
        getLogger().info(zones.all().size() + " Zone(n) geladen.");
    }

    @Override
    public void onDisable() {
        if (zones != null) {
            zones.close();
        }
        if (history != null) {
            history.flush();
        }
    }

    // ---------------------------------------------------------------- Befehl

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        boolean admin = sender.hasPermission(PERMISSION);
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);

        if (!admin) {
            boolean allowed = (sub.equals("zone") || sub.equals("credits"))
                    && sender instanceof Player p && credits.count(p.getUniqueId()) > 0;
            if (!allowed) {
                sender.sendMessage(Component.text("Dafür hast du keine Berechtigung.", NamedTextColor.RED));
                return true;
            }
        }

        switch (sub) {
            case "zone" -> createZone(sender, args, admin);
            case "list" -> listZones(sender);
            case "remove" -> removeZone(sender, args);
            case "give" -> giveCredits(sender, args);
            case "credits" -> showCredits(sender);
            case "history" -> showHistory(sender, args);
            case "rollback" -> rollback(sender, args);
            case "safe" -> safeZone(sender, args);
            default -> usage(sender);
        }
        return true;
    }

    private void usage(CommandSender sender) {
        String[] lines = {
                "/AntiGrief Zone <Radius> <Farbe> <Name> <Message>",
                "/AntiGrief Give <Spieler> <Anzahl> <MaxRadius>",
                "/AntiGrief History [Zonenname|Spieler] [Seite]",
                "/AntiGrief Rollback <Zonenname> Place|Destroy",
                "/AntiGrief Safe <Zonenname>",
                "/AntiGrief List",
                "/AntiGrief Remove <Zonenname>",
                "/AntiGrief Credits"
        };
        for (String l : lines) {
            sender.sendMessage(Component.text(l, NamedTextColor.YELLOW));
        }
    }

    private static void error(CommandSender sender, String text) {
        sender.sendMessage(Component.text(text, NamedTextColor.RED));
    }

    private static Integer parseInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ Zone

    private void createZone(CommandSender sender, String[] args, boolean admin) {
        if (!(sender instanceof Player player)) {
            error(sender, "Nur Spieler können Zonen erstellen.");
            return;
        }
        if (args.length < 5) {
            error(sender, "Benutzung: /AntiGrief Zone <Radius> <Farbe> <Name> <Message>");
            return;
        }

        Integer radius = parseInt(args[1]);
        if (radius == null) {
            error(sender, "Der Radius muss eine Zahl sein.");
            return;
        }
        if (radius < 1 || radius > MAX_RADIUS) {
            error(sender, "Der Radius muss zwischen 1 und " + MAX_RADIUS + " liegen.");
            return;
        }
        if (!admin) {
            int max = credits.maxRadius(player.getUniqueId());
            if (radius > max) {
                error(sender, "Du darfst maximal einen Radius von " + max + " benutzen.");
                return;
            }
        }

        int rgb = ColorUtil.parse(args[2]);
        if (rgb < 0) {
            error(sender, "Unbekannte Farbe. Nutze z. B. rot, blau, gruen, gelb, orange, "
                    + "lila, pink oder einen Hex-Code wie #FF8800.");
            return;
        }

        String name = args[3];
        if (!NAME_PATTERN.matcher(name).matches()) {
            error(sender, "Der Name darf nur aus Buchstaben, Zahlen, _ und - bestehen (max. 24 Zeichen).");
            return;
        }
        if (zones.byName(name) != null) {
            error(sender, "Es gibt schon eine Zone mit dem Namen " + name + ".");
            return;
        }

        String message = String.join(" ", Arrays.copyOfRange(args, 4, args.length));
        Location loc = player.getLocation();
        String world = loc.getWorld().getName();
        int cx = loc.getBlockX();
        int cz = loc.getBlockZ();

        if (!admin) {
            if (zones.overlaps(world, cx - radius, cx + radius, cz - radius, cz + radius)) {
                error(sender, "Diese Zone würde sich mit einer bestehenden Zone überschneiden.");
                return;
            }
            if (!credits.consume(player.getUniqueId(), radius)) {
                error(sender, "Du hast keine passende Zonen-Möglichkeit mehr.");
                return;
            }
        }

        Zone zone = zones.add(name, world, cx, cz, radius, args[2].toLowerCase(Locale.ROOT), rgb,
                message, player.getName());
        String extra = admin ? "" : " Übrige Möglichkeiten: " + credits.count(player.getUniqueId()) + ".";
        sender.sendMessage(Component.text("Zone " + zone.name() + " erstellt (Radius " + radius
                + ", Mittelpunkt " + cx + " / " + cz + ")." + extra, TextColor.color(rgb)));
    }

    private void listZones(CommandSender sender) {
        if (zones.all().isEmpty()) {
            sender.sendMessage(Component.text("Es gibt noch keine Zonen.", NamedTextColor.GRAY));
            return;
        }
        for (Zone z : zones.all()) {
            sender.sendMessage(Component.text(z.name() + " [" + z.world() + "] X " + z.minX() + " bis "
                    + z.maxX() + ", Z " + z.minZ() + " bis " + z.maxZ() + " | von " + z.owner()
                    + " | Änderungen seit Safe: " + z.baseline().size(), TextColor.color(z.rgb())));
        }
    }

    private void removeZone(CommandSender sender, String[] args) {
        if (args.length < 2) {
            error(sender, "Benutzung: /AntiGrief Remove <Zonenname>");
            return;
        }
        Zone zone = zones.byName(args[1]);
        if (zone == null) {
            error(sender, "Keine Zone mit dem Namen " + args[1] + ".");
            return;
        }
        zones.remove(zone);
        sender.sendMessage(Component.text("Zone " + zone.name() + " gelöscht.", NamedTextColor.GREEN));
    }

    // ------------------------------------------------------------------ Give

    private void giveCredits(CommandSender sender, String[] args) {
        if (args.length < 4) {
            error(sender, "Benutzung: /AntiGrief Give <Spieler> <Anzahl> <MaxRadius>");
            return;
        }
        OfflinePlayer target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            target = Bukkit.getOfflinePlayerIfCached(args[1]);
        }
        if (target == null) {
            error(sender, "Spieler " + args[1] + " nicht gefunden (er muss schon einmal auf dem Server gewesen sein).");
            return;
        }
        Integer count = parseInt(args[2]);
        Integer maxRadius = parseInt(args[3]);
        if (count == null || count < 1 || count > MAX_CREDITS_PER_GIVE) {
            error(sender, "Die Anzahl muss zwischen 1 und " + MAX_CREDITS_PER_GIVE + " liegen.");
            return;
        }
        if (maxRadius == null || maxRadius < 1 || maxRadius > MAX_RADIUS) {
            error(sender, "Der MaxRadius muss zwischen 1 und " + MAX_RADIUS + " liegen.");
            return;
        }

        credits.give(target.getUniqueId(), count, maxRadius);
        String targetName = target.getName() != null ? target.getName() : args[1];
        sender.sendMessage(Component.text(targetName + " kann jetzt " + count + "x eine Zone mit max. Radius "
                + maxRadius + " platzieren.", NamedTextColor.GREEN));

        Player online = target.getPlayer();
        if (online != null) {
            online.sendMessage(Component.text("Du kannst " + count + "x eine grieffreie Zone (max. Radius "
                    + maxRadius + ") platzieren: /AntiGrief Zone <Radius> <Farbe> <Name> <Message>",
                    NamedTextColor.GREEN));
        }
    }

    private void showCredits(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            error(sender, "Nur Spieler haben Zonen-Möglichkeiten.");
            return;
        }
        List<Integer> list = credits.list(player.getUniqueId());
        if (list.isEmpty()) {
            sender.sendMessage(Component.text("Du hast keine Zonen-Möglichkeiten.", NamedTextColor.GRAY));
            return;
        }
        Map<Integer, Integer> grouped = new TreeMap<>();
        for (int r : list) {
            grouped.merge(r, 1, Integer::sum);
        }
        for (Map.Entry<Integer, Integer> en : grouped.entrySet()) {
            sender.sendMessage(Component.text(en.getValue() + "x mit max. Radius " + en.getKey(),
                    NamedTextColor.YELLOW));
        }
    }

    // --------------------------------------------------------------- History

    private void showHistory(CommandSender sender, String[] args) {
        String zoneFilter = null;
        String actorFilter = null;
        int page = 1;
        if (args.length >= 2) {
            Integer n = parseInt(args[1]);
            if (n != null) {
                page = n;
            } else {
                Zone z = zones.byName(args[1]);
                if (z != null) {
                    zoneFilter = z.name();
                } else {
                    actorFilter = args[1];
                }
                if (args.length >= 3) {
                    Integer pn = parseInt(args[2]);
                    if (pn != null) {
                        page = pn;
                    }
                }
            }
        }

        List<HistoryStore.Entry> list = history.query(zoneFilter, actorFilter);
        if (list.isEmpty()) {
            sender.sendMessage(Component.text("Keine Einträge gefunden.", NamedTextColor.GRAY));
            return;
        }
        int pages = (list.size() + HISTORY_PAGE_SIZE - 1) / HISTORY_PAGE_SIZE;
        page = Math.max(1, Math.min(page, pages));
        String title = zoneFilter != null ? "Zone " + zoneFilter
                : actorFilter != null ? "Spieler/Quelle " + actorFilter : "alle Zonen";
        sender.sendMessage(Component.text("--- History: " + title + " (Seite " + page + "/" + pages + ") ---",
                NamedTextColor.GOLD));

        int from = (page - 1) * HISTORY_PAGE_SIZE;
        int to = Math.min(list.size(), from + HISTORY_PAGE_SIZE);
        for (int i = from; i < to; i++) {
            HistoryStore.Entry e = list.get(i);
            boolean oldEmpty = BlockUtil.emptyLikeName(e.oldMat());
            boolean newEmpty = BlockUtil.emptyLikeName(e.newMat());
            String text;
            NamedTextColor color;
            if (oldEmpty) {
                text = e.actor() + " hat " + BlockUtil.pretty(e.newMat()) + " platziert";
                color = NamedTextColor.GREEN;
            } else if (newEmpty) {
                text = e.actor() + " hat " + BlockUtil.pretty(e.oldMat()) + " zerstört";
                color = NamedTextColor.RED;
            } else {
                text = e.actor() + " hat " + BlockUtil.pretty(e.oldMat()) + " durch "
                        + BlockUtil.pretty(e.newMat()) + " ersetzt";
                color = NamedTextColor.YELLOW;
            }
            sender.sendMessage(Component.text("[" + TIME_FORMAT.format(Instant.ofEpochMilli(e.time())) + "] ",
                            NamedTextColor.GRAY)
                    .append(Component.text(text, color))
                    .append(Component.text(" (" + e.x() + " " + e.y() + " " + e.z() + ", Zone " + e.zone() + ")",
                            NamedTextColor.DARK_GRAY)));
        }
    }

    // -------------------------------------------------------- Safe & Rollback

    private void safeZone(CommandSender sender, String[] args) {
        if (args.length < 2) {
            error(sender, "Benutzung: /AntiGrief Safe <Zonenname>");
            return;
        }
        Zone zone = zones.byName(args[1]);
        if (zone == null) {
            error(sender, "Keine Zone mit dem Namen " + args[1] + ".");
            return;
        }
        if (busy.contains(zone.name().toLowerCase(Locale.ROOT))) {
            error(sender, "Für diese Zone läuft gerade ein Rollback.");
            return;
        }
        int n = zone.baseline().size();
        zone.baseline().clear();
        zone.markDirty();
        zones.flushDirty(true);
        sender.sendMessage(Component.text("Zone " + zone.name() + " gesichert: " + n
                + " veränderte Block(s) sind jetzt der neue Zustand.", NamedTextColor.GREEN));
    }

    private void rollback(CommandSender sender, String[] args) {
        if (args.length < 3) {
            error(sender, "Benutzung: /AntiGrief Rollback <Zonenname> Place|Destroy");
            return;
        }
        Zone zone = zones.byName(args[1]);
        if (zone == null) {
            error(sender, "Keine Zone mit dem Namen " + args[1] + ".");
            return;
        }
        String mode = args[2].toLowerCase(Locale.ROOT);
        if (!mode.equals("place") && !mode.equals("destroy")) {
            error(sender, "Modus muss Place oder Destroy sein.");
            return;
        }
        World world = Bukkit.getWorld(zone.world());
        if (world == null) {
            error(sender, "Die Welt " + zone.world() + " ist nicht geladen.");
            return;
        }
        String busyKey = zone.name().toLowerCase(Locale.ROOT);
        if (!busy.add(busyKey)) {
            error(sender, "Für diese Zone läuft bereits ein Rollback.");
            return;
        }
        if (zone.baseline().isEmpty()) {
            busy.remove(busyKey);
            sender.sendMessage(Component.text("Keine Änderungen seit dem letzten Safe.", NamedTextColor.GRAY));
            return;
        }

        final boolean place = mode.equals("place");
        final List<Map.Entry<Pos, BlockData>> todo = new ArrayList<>();
        for (Map.Entry<Pos, BlockData> en : zone.baseline().entrySet()) {
            todo.add(Map.entry(en.getKey(), en.getValue()));
        }
        sender.sendMessage(Component.text("Rollback gestartet (" + todo.size() + " Positionen) ...",
                NamedTextColor.YELLOW));

        new BukkitRunnable() {
            int index = 0;
            int changed = 0;

            @Override
            public void run() {
                int end = Math.min(index + ROLLBACK_BLOCKS_PER_TICK, todo.size());
                for (; index < end; index++) {
                    Map.Entry<Pos, BlockData> en = todo.get(index);
                    Pos pos = en.getKey();
                    BlockData base = en.getValue();
                    Block block = world.getBlockAt(pos.x(), pos.y(), pos.z());
                    BlockData cur = block.getBlockData();

                    if (BlockUtil.equivalent(base, cur)) {
                        if (zone.baseline().remove(pos) != null) {
                            zone.markDirty();
                        }
                        continue;
                    }
                    if (place) {
                        // zerstörte Blöcke wieder hinsetzen
                        if (!BlockUtil.emptyLike(base.getMaterial())) {
                            block.setBlockData(base, false);
                            changed++;
                            zone.baseline().remove(pos);
                            zone.markDirty();
                        }
                    } else {
                        // platzierte Blöcke zerstören
                        if (!BlockUtil.emptyLike(cur.getMaterial())) {
                            boolean baseEmpty = BlockUtil.emptyLike(base.getMaterial());
                            block.setBlockData(baseEmpty ? base : Material.AIR.createBlockData(), false);
                            changed++;
                            if (baseEmpty) {
                                zone.baseline().remove(pos);
                                zone.markDirty();
                            }
                        }
                    }
                }
                if (index >= todo.size()) {
                    cancel();
                    busy.remove(busyKey);
                    String what = place ? "wiederhergestellt" : "entfernt";
                    sender.sendMessage(Component.text("Rollback (" + (place ? "Place" : "Destroy")
                            + ") für Zone " + zone.name() + " fertig: " + changed + " Block(s) " + what + ".",
                            NamedTextColor.GREEN));
                }
            }
        }.runTaskTimer(this, 1L, 1L);
    }

    // ------------------------------------------------------------ Tab-Complete

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission(PERMISSION);
        boolean hasCredits = sender instanceof Player p && credits.count(p.getUniqueId()) > 0;
        if (!admin && !hasCredits) {
            return out;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);

        if (args.length == 1) {
            if (admin) {
                out.addAll(List.of("zone", "give", "history", "rollback", "safe", "list", "remove", "credits"));
            } else {
                out.addAll(List.of("zone", "credits"));
            }
        } else if (sub.equals("zone")) {
            if (args.length == 2) {
                out.addAll(List.of("10", "25", "50", "100"));
            } else if (args.length == 3) {
                ColorUtil.names().forEach(out::add);
            } else if (args.length == 4) {
                out.add("<Name>");
            } else if (args.length == 5) {
                out.add("<Message>");
            }
        } else if (admin) {
            if (sub.equals("give")) {
                if (args.length == 2) {
                    Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                } else if (args.length == 3) {
                    out.addAll(List.of("1", "3", "5"));
                } else if (args.length == 4) {
                    out.addAll(List.of("25", "50", "100"));
                }
            } else if (args.length == 2 && List.of("history", "rollback", "safe", "remove").contains(sub)) {
                zones.all().forEach(z -> out.add(z.name()));
                if (sub.equals("history")) {
                    Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                }
            } else if (sub.equals("rollback") && args.length == 3) {
                out.addAll(List.of("Place", "Destroy"));
            }
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }

    // ------------------------------------------------------- Zone betreten

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (!event.hasChangedBlock()) {
            return;
        }
        Player player = event.getPlayer();
        Location from = event.getFrom();
        Location to = event.getTo();
        for (Zone z : zones.all()) {
            if (z.contains(to) && !z.contains(from)) {
                Component text = Component.text(z.message(), TextColor.color(z.rgb()));
                player.sendMessage(text);
                player.sendActionBar(text);
            }
        }
    }

    // ------------------------------------------------------ Zone markieren

    private void drawBorders() {
        if (zones.all().isEmpty()) {
            return;
        }
        for (Player p : Bukkit.getOnlinePlayers()) {
            Location pl = p.getLocation();
            String world = pl.getWorld().getName();
            for (Zone z : zones.all()) {
                if (!z.world().equals(world) || z.distanceTo(pl) > RENDER_DISTANCE) {
                    continue;
                }
                Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB(z.rgb()), 1.6f);
                double x1 = z.minX();
                double x2 = z.maxX() + 1.0;
                double z1 = z.minZ();
                double z2 = z.maxZ() + 1.0;
                double baseY = Math.floor(pl.getY());
                for (double h : new double[]{0.2, 1.2, 2.2}) {
                    double y = baseY + h;
                    lineX(p, x1, x2, z1, y, dust);
                    lineX(p, x1, x2, z2, y, dust);
                    lineZ(p, z1, z2, x1, y, dust);
                    lineZ(p, z1, z2, x2, y, dust);
                }
            }
        }
    }

    /** Linie entlang der X-Achse bei fixem Z. */
    private void lineX(Player p, double xa, double xb, double fixedZ, double y, Particle.DustOptions dust) {
        Location pl = p.getLocation();
        if (Math.abs(fixedZ - pl.getZ()) > LINE_RANGE) {
            return;
        }
        double from = Math.max(xa, pl.getX() - LINE_RANGE);
        double to = Math.min(xb, pl.getX() + LINE_RANGE);
        for (double x = from; x <= to; x += 1.5) {
            p.spawnParticle(Particle.DUST, x, y, fixedZ, 1, 0, 0, 0, 0, dust);
        }
    }

    /** Linie entlang der Z-Achse bei fixem X. */
    private void lineZ(Player p, double za, double zb, double fixedX, double y, Particle.DustOptions dust) {
        Location pl = p.getLocation();
        if (Math.abs(fixedX - pl.getX()) > LINE_RANGE) {
            return;
        }
        double from = Math.max(za, pl.getZ() - LINE_RANGE);
        double to = Math.min(zb, pl.getZ() + LINE_RANGE);
        for (double zz = from; zz <= to; zz += 1.5) {
            p.spawnParticle(Particle.DUST, fixedX, y, zz, 1, 0, 0, 0, 0, dust);
        }
    }
}
