package de.antigrief;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Verwaltet, wie oft ein Spieler noch eine Zone platzieren darf (jede Möglichkeit hat einen Max-Radius). */
public final class CreditManager {

    private final JavaPlugin plugin;
    private final File file;
    private final Map<UUID, List<Integer>> credits = new HashMap<>();

    public CreditManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "credits.yml");
    }

    public void load() {
        credits.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        var root = cfg.getConfigurationSection("credits");
        if (root == null) {
            return;
        }
        for (String key : root.getKeys(false)) {
            try {
                credits.put(UUID.fromString(key), new ArrayList<>(root.getIntegerList(key)));
            } catch (IllegalArgumentException ignored) {
                // ungültige UUID überspringen
            }
        }
    }

    private void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Map.Entry<UUID, List<Integer>> en : credits.entrySet()) {
            if (!en.getValue().isEmpty()) {
                cfg.set("credits." + en.getKey(), en.getValue());
            }
        }
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("credits.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    public void give(UUID player, int count, int maxRadius) {
        List<Integer> list = credits.computeIfAbsent(player, k -> new ArrayList<>());
        for (int i = 0; i < count; i++) {
            list.add(maxRadius);
        }
        save();
    }

    public int count(UUID player) {
        List<Integer> list = credits.get(player);
        return list == null ? 0 : list.size();
    }

    public int maxRadius(UUID player) {
        List<Integer> list = credits.get(player);
        int max = 0;
        if (list != null) {
            for (int r : list) {
                max = Math.max(max, r);
            }
        }
        return max;
    }

    public List<Integer> list(UUID player) {
        List<Integer> list = credits.get(player);
        return list == null ? new ArrayList<>() : new ArrayList<>(list);
    }

    /** Verbraucht die kleinste Möglichkeit, deren Max-Radius für den Radius reicht. */
    public boolean consume(UUID player, int radius) {
        List<Integer> list = credits.get(player);
        if (list == null) {
            return false;
        }
        int best = -1;
        for (int i = 0; i < list.size(); i++) {
            int max = list.get(i);
            if (max >= radius && (best < 0 || max < list.get(best))) {
                best = i;
            }
        }
        if (best < 0) {
            return false;
        }
        list.remove(best);
        save();
        return true;
    }
}
