package de.antigrief;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Erfasst Blockänderungen in Zonen. Vor einer Änderung wird der alte Block gemerkt,
 * 2 Ticks später verglichen. Nur Material-Änderungen zählen (Wasser/Lava/Feuer gelten als "leer").
 */
public final class ChangeTracker implements Listener {

    private static final BlockFace[] FACES = {
            BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST
    };

    private record Pending(String key, World world, int x, int y, int z, BlockData old, String actor) {
    }

    private final JavaPlugin plugin;
    private final ZoneManager zones;
    private final HistoryStore history;
    private final Map<String, Pending> pending = new HashMap<>();

    public ChangeTracker(JavaPlugin plugin, ZoneManager zones, HistoryStore history) {
        this.plugin = plugin;
        this.zones = zones;
        this.history = history;
    }

    // ------------------------------------------------------------------ Kern

    private void track(Collection<Block> blocks, String actor) {
        if (zones.isEmpty()) {
            return;
        }
        List<Pending> batch = new java.util.ArrayList<>();
        for (Block b : blocks) {
            if (zones.zonesAt(b.getWorld(), b.getX(), b.getZ()).isEmpty()) {
                continue;
            }
            String key = b.getWorld().getUID() + ":" + b.getX() + ":" + b.getY() + ":" + b.getZ();
            if (pending.containsKey(key)) {
                continue;
            }
            Pending p = new Pending(key, b.getWorld(), b.getX(), b.getY(), b.getZ(), b.getBlockData(), actor);
            pending.put(key, p);
            batch.add(p);
        }
        if (batch.isEmpty()) {
            return;
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> finish(batch), 2L);
    }

    private void finish(List<Pending> batch) {
        for (Pending p : batch) {
            pending.remove(p.key());
            BlockData now = p.world().getBlockAt(p.x(), p.y(), p.z()).getBlockData();
            if (BlockUtil.equivalent(p.old(), now)) {
                continue;
            }
            Pos pos = new Pos(p.x(), p.y(), p.z());
            for (Zone zone : zones.zonesAt(p.world(), p.x(), p.z())) {
                BlockData base = zone.baseline().get(pos);
                if (base == null) {
                    zone.baseline().put(pos, p.old());
                } else if (BlockUtil.equivalent(base, now)) {
                    zone.baseline().remove(pos);
                }
                zone.markDirty();
                history.add(new HistoryStore.Entry(System.currentTimeMillis(), zone.name(), p.actor(),
                        p.old().getMaterial().name(), now.getMaterial().name(), p.x(), p.y(), p.z()));
            }
        }
    }

    /** Nur ins Protokoll schreiben (z. B. Wasser-/Lavaeimer, Feuer legen), ohne Rollback-Daten. */
    private void logOnly(Block b, String actor, Material oldM, Material newM) {
        for (Zone zone : zones.zonesAt(b.getWorld(), b.getX(), b.getZ())) {
            history.add(new HistoryStore.Entry(System.currentTimeMillis(), zone.name(), actor,
                    oldM.name(), newM.name(), b.getX(), b.getY(), b.getZ()));
        }
    }

    private static void addWithNeighbors(Set<Block> out, Block b) {
        out.add(b);
        for (BlockFace f : FACES) {
            out.add(b.getRelative(f));
        }
    }

    private static String describe(Entity en) {
        if (en == null) {
            return "Unbekannt";
        }
        if (en instanceof Player p) {
            return p.getName();
        }
        if (en instanceof TNTPrimed t) {
            Entity src = t.getSource();
            return src instanceof Player sp ? "TNT von " + sp.getName() : "TNT";
        }
        if (en instanceof FallingBlock) {
            return "Fallender Block";
        }
        return BlockUtil.pretty(en.getType().name());
    }

    // -------------------------------------------------------------- Spieler

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        Action action = e.getAction();
        if ((action != Action.RIGHT_CLICK_BLOCK && action != Action.RIGHT_CLICK_AIR) || !e.hasItem()) {
            return;
        }
        ItemStack item = e.getItem();
        if (item == null) {
            return;
        }
        Material m = item.getType();
        boolean relevant = m.isBlock() || m.name().endsWith("_BUCKET")
                || m == Material.FLINT_AND_STEEL || m == Material.FIRE_CHARGE;
        if (!relevant) {
            return;
        }
        Block c = e.getClickedBlock();
        if (c == null) {
            // z. B. Seerose auf Wasser: Zielblock per Raycast bestimmen
            c = e.getPlayer().getTargetBlockExact(6, FluidCollisionMode.ALWAYS);
            if (c == null) {
                return;
            }
        }
        Set<Block> area = new HashSet<>();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    area.add(c.getRelative(dx, dy, dz));
                }
            }
        }
        track(area, e.getPlayer().getName());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        Set<Block> area = new HashSet<>();
        addWithNeighbors(area, b);
        Block up = b;
        for (int i = 0; i < 16; i++) {
            up = up.getRelative(BlockFace.UP);
            if (BlockUtil.emptyLike(up.getType())) {
                break;
            }
            area.add(up);
        }
        track(area, e.getPlayer().getName());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        Material bucket = e.getBucket();
        Material liquid;
        if (bucket == Material.WATER_BUCKET) {
            liquid = Material.WATER;
        } else if (bucket == Material.LAVA_BUCKET) {
            liquid = Material.LAVA;
        } else {
            return;
        }
        logOnly(e.getBlock(), e.getPlayer().getName(), Material.AIR, liquid);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (e.getIgnitingEntity() instanceof Player p) {
            logOnly(e.getBlock(), p.getName(), Material.AIR, Material.FIRE);
        }
    }

    // ----------------------------------------------------- TNT & Explosionen

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTntSpawn(EntitySpawnEvent e) {
        if (e.getEntity() instanceof TNTPrimed t) {
            Set<Block> set = new HashSet<>();
            set.add(t.getLocation().getBlock());
            track(set, describe(t));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        Set<Block> set = new HashSet<>();
        for (Block b : e.blockList()) {
            addWithNeighbors(set, b);
        }
        track(set, describe(e.getEntity()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        Set<Block> set = new HashSet<>();
        for (Block b : e.blockList()) {
            addWithNeighbors(set, b);
        }
        track(set, "Explosion");
    }

    // ----------------------------------------------- Feuer, Flüssigkeiten, Sonstiges

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        Set<Block> set = new HashSet<>();
        addWithNeighbors(set, e.getBlock());
        track(set, "Feuer");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        if (zones.isEmpty()) {
            return;
        }
        Block to = e.getToBlock();
        if (BlockUtil.emptyLike(to.getType())) {
            return; // nichts Festes wird zerstört
        }
        Material src = e.getBlock().getType();
        String actor = src == Material.LAVA ? "Lava" : src == Material.WATER ? "Wasser" : "Flüssigkeit";
        Set<Block> set = new HashSet<>();
        set.add(to);
        track(set, actor);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        Set<Block> set = new HashSet<>();
        addWithNeighbors(set, e.getBlock());
        for (Block b : e.getBlocks()) {
            addWithNeighbors(set, b);
        }
        track(set, "Kolben");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        Set<Block> set = new HashSet<>();
        addWithNeighbors(set, e.getBlock());
        for (Block b : e.getBlocks()) {
            addWithNeighbors(set, b);
        }
        track(set, "Kolben");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent e) {
        Set<Block> set = new HashSet<>();
        set.add(e.getBlock());
        set.add(e.getBlock().getRelative(BlockFace.UP));
        track(set, describe(e.getEntity()));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDispense(BlockDispenseEvent e) {
        if (!(e.getBlock().getBlockData() instanceof Directional d)) {
            return;
        }
        Set<Block> set = new HashSet<>();
        addWithNeighbors(set, e.getBlock().getRelative(d.getFacing()));
        track(set, "Dispenser");
    }
}
