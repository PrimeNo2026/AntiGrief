package de.antigrief;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class ZoneManager {

    private final JavaPlugin plugin;
    private final File file;
    private final File diffDir;
    private final List<Zone> zones = new ArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private int nextId = 1;

    public ZoneManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "zones.yml");
        this.diffDir = new File(plugin.getDataFolder(), "diff");
    }

    // ------------------------------------------------------------ Laden/Speichern

    public void load() {
        zones.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("zones");
        if (root == null) {
            return;
        }
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) {
                continue;
            }
            int id = Integer.parseInt(key);
            Zone zone = new Zone(id,
                    s.getString("name", "zone" + id),
                    s.getString("world", "world"),
                    s.getInt("minX"), s.getInt("maxX"),
                    s.getInt("minZ"), s.getInt("maxZ"),
                    s.getString("color", "rot"),
                    s.getInt("rgb", 0xFF3B3B),
                    s.getString("message", ""),
                    s.getString("owner", "Admin"));
            zones.add(zone);
            nextId = Math.max(nextId, id + 1);
            loadDiff(zone);
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Zone z : zones) {
            String p = "zones." + z.id() + ".";
            cfg.set(p + "name", z.name());
            cfg.set(p + "world", z.world());
            cfg.set(p + "minX", z.minX());
            cfg.set(p + "maxX", z.maxX());
            cfg.set(p + "minZ", z.minZ());
            cfg.set(p + "maxZ", z.maxZ());
            cfg.set(p + "color", z.colorName());
            cfg.set(p + "rgb", z.rgb());
            cfg.set(p + "message", z.message());
            cfg.set(p + "owner", z.owner());
        }
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("zones.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    private File diffFile(Zone zone) {
        return new File(diffDir, zone.name().toLowerCase(Locale.ROOT) + ".txt");
    }

    private void loadDiff(Zone zone) {
        File f = diffFile(zone);
        if (!f.exists()) {
            return;
        }
        try {
            for (String line : Files.readAllLines(f.toPath(), StandardCharsets.UTF_8)) {
                String[] p = line.split(" ", 4);
                if (p.length < 4) {
                    continue;
                }
                try {
                    zone.baseline().put(
                            new Pos(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])),
                            Bukkit.createBlockData(p[3]));
                } catch (IllegalArgumentException ignored) {
                    // kaputte Zeile überspringen
                }
            }
        } catch (IOException e) {
            plugin.getLogger().severe("Konnte " + f.getName() + " nicht lesen: " + e.getMessage());
        }
    }

    /** Speichert alle veränderten Zonen-Zustände (async über eine einzelne Schreib-Queue). */
    public void flushDirty(boolean async) {
        for (Zone zone : zones) {
            if (!zone.isDirty()) {
                continue;
            }
            zone.clearDirty();
            List<String> lines = new ArrayList<>(zone.baseline().size());
            for (Map.Entry<Pos, BlockData> en : zone.baseline().entrySet()) {
                Pos p = en.getKey();
                lines.add(p.x() + " " + p.y() + " " + p.z() + " " + en.getValue().getAsString());
            }
            File f = diffFile(zone);
            Runnable write = () -> {
                try {
                    diffDir.mkdirs();
                    Files.write(f.toPath(), lines, StandardCharsets.UTF_8);
                } catch (IOException e) {
                    plugin.getLogger().severe("Konnte " + f.getName() + " nicht schreiben: " + e.getMessage());
                }
            };
            if (async) {
                io.submit(write);
            } else {
                write.run();
            }
        }
    }

    public void close() {
        flushDirty(true);
        io.shutdown();
        try {
            io.awaitTermination(20, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // ------------------------------------------------------------------ Zugriff

    public Zone add(String name, String world, int cx, int cz, int radius, String colorName, int rgb,
                    String message, String owner) {
        Zone z = new Zone(nextId++, name, world, cx - radius, cx + radius, cz - radius, cz + radius,
                colorName, rgb, message, owner);
        zones.add(z);
        save();
        return z;
    }

    public boolean remove(Zone zone) {
        boolean removed = zones.remove(zone);
        if (removed) {
            File f = diffFile(zone);
            io.submit(() -> {
                f.delete();
            });
            save();
        }
        return removed;
    }

    public Zone byName(String name) {
        for (Zone z : zones) {
            if (z.name().equalsIgnoreCase(name)) {
                return z;
            }
        }
        return null;
    }

    public boolean overlaps(String world, int minX, int maxX, int minZ, int maxZ) {
        for (Zone z : zones) {
            if (z.intersects(world, minX, maxX, minZ, maxZ)) {
                return true;
            }
        }
        return false;
    }

    public boolean isEmpty() {
        return zones.isEmpty();
    }

    public List<Zone> zonesAt(World world, int x, int z) {
        if (zones.isEmpty()) {
            return Collections.emptyList();
        }
        List<Zone> out = null;
        String wn = world.getName();
        for (Zone zone : zones) {
            if (zone.contains(wn, x, z)) {
                if (out == null) {
                    out = new ArrayList<>(2);
                }
                out.add(zone);
            }
        }
        return out == null ? Collections.emptyList() : out;
    }

    public List<Zone> all() {
        return Collections.unmodifiableList(zones);
    }
}
