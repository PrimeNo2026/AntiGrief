package de.antigrief;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public final class ColorUtil {

    private static final Map<String, Integer> COLORS = new LinkedHashMap<>();

    static {
        put(0xFF3B3B, "rot", "red");
        put(0x3B6BFF, "blau", "blue");
        put(0x3BD64B, "gruen", "grün", "green");
        put(0xFFE53B, "gelb", "yellow");
        put(0xFF9A2E, "orange");
        put(0xA64BFF, "lila", "purple");
        put(0xFF6FD8, "pink");
        put(0x3BE0FF, "tuerkis", "türkis", "cyan", "aqua");
        put(0xFFFFFF, "weiss", "weiß", "white");
        put(0x9A9A9A, "grau", "gray", "grey");
        put(0x1A1A1A, "schwarz", "black");
        put(0x8B5A2B, "braun", "brown");
    }

    private ColorUtil() {
    }

    private static void put(int rgb, String... names) {
        for (String n : names) {
            COLORS.put(n, rgb);
        }
    }

    /** Liefert den RGB-Wert oder -1, wenn die Farbe unbekannt ist. Unterstützt Namen und #RRGGBB. */
    public static int parse(String input) {
        String s = input.toLowerCase(Locale.ROOT);
        if (s.startsWith("#") && s.length() == 7) {
            try {
                return Integer.parseInt(s.substring(1), 16);
            } catch (NumberFormatException ignored) {
                return -1;
            }
        }
        return COLORS.getOrDefault(s, -1);
    }

    public static Iterable<String> names() {
        return COLORS.keySet();
    }
}
