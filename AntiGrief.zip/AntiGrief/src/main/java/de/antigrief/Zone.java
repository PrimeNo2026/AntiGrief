package de.antigrief;

import org.bukkit.Location;
import org.bukkit.block.data.BlockData;

import java.util.HashMap;
import java.util.Map;

/**
 * Eine viereckige Zone (über die gesamte Höhe der Welt).
 * "baseline" speichert für jede seit dem letzten Safe veränderte Position den Originalblock.
 */
public final class Zone {

    private final int id;
    private final String name;
    private final String world;
    private final int minX;
    private final int maxX;
    private final int minZ;
    private final int maxZ;
    private final String colorName;
    private final int rgb;
    private final String message;
    private final String owner;
    private final Map<Pos, BlockData> baseline = new HashMap<>();
    private boolean dirty;

    public Zone(int id, String name, String world, int minX, int maxX, int minZ, int maxZ,
                String colorName, int rgb, String message, String owner) {
        this.id = id;
        this.name = name;
        this.world = world;
        this.minX = minX;
        this.maxX = maxX;
        this.minZ = minZ;
        this.maxZ = maxZ;
        this.colorName = colorName;
        this.rgb = rgb;
        this.message = message;
        this.owner = owner;
    }

    public int id() { return id; }
    public String name() { return name; }
    public String world() { return world; }
    public int minX() { return minX; }
    public int maxX() { return maxX; }
    public int minZ() { return minZ; }
    public int maxZ() { return maxZ; }
    public String colorName() { return colorName; }
    public int rgb() { return rgb; }
    public String message() { return message; }
    public String owner() { return owner; }
    public Map<Pos, BlockData> baseline() { return baseline; }
    public boolean isDirty() { return dirty; }
    public void markDirty() { dirty = true; }
    public void clearDirty() { dirty = false; }

    public boolean contains(String worldName, int x, int z) {
        return world.equals(worldName) && x >= minX && x <= maxX && z >= minZ && z <= maxZ;
    }

    public boolean contains(Location loc) {
        if (loc.getWorld() == null) {
            return false;
        }
        return contains(loc.getWorld().getName(), loc.getBlockX(), loc.getBlockZ());
    }

    public boolean intersects(String worldName, int oMinX, int oMaxX, int oMinZ, int oMaxZ) {
        return world.equals(worldName) && oMinX <= maxX && oMaxX >= minX && oMinZ <= maxZ && oMaxZ >= minZ;
    }

    /** Horizontale Entfernung von einer Position zum Zonenrand (0 = innerhalb). */
    public double distanceTo(Location loc) {
        double dx = Math.max(Math.max(minX - loc.getX(), 0), loc.getX() - (maxX + 1));
        double dz = Math.max(Math.max(minZ - loc.getZ(), 0), loc.getZ() - (maxZ + 1));
        return Math.hypot(dx, dz);
    }
}
